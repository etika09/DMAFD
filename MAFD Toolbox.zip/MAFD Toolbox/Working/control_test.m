clear all
close all
load('controllers_5bus_test_working.mat')
load('closed_loop_5bus_test_working.mat')
load('open_loop_5bus_test_working.mat')

w=[zeros(50,10);10*repmat([0.15 0.15 0.15 0.15 0.15 0.15 0.15 0.15 0.15 0.15],30,1);10*repmat([0.15 0.15 0.15 0.15 0.15 0.15 0.15 0.15 0.15 0.15],20,1);zeros(151,10)];
%w=[zeros(50,6);repmat([0 0 0 0 0 0],30,1);zeros(220,6)];
sigma_i = [1 2]; %mode nummbers in each microgrid (this is \sigma_i from the paper)
n_m = 2; %number of switching modes for each microgrid 
sigma = combvec(sigma_i,sigma_i,sigma_i,sigma_i,sigma_i)';
%% closed loop response
t1=0:0.1:4;
[Y1, Tsim1, X1]=lsim(sys{1},w(1:41,:),t1);
t2=4.0:0.1:6;
[Y2, Tsim2, X2]=lsim(sys{27},w(41:61,:),t2,X1(end,:));
t3=6.0:0.1:12;
[Y3, Tsim3, X3]=lsim(sys{32},w(61:121,:),t3,X2(end,:));
t4=12.0:0.1:25;
[Y4, Tsim4, X4]=lsim(sys{1},w(121:251,:),t4,X3(end,:));
% t5=8.0:0.1:10;
% [Y5, Tsim5, X5]=lsim(sys{29},w(81:101,:),t5,X4(end,:));

% Y=[Y1;Y2;Y3;Y4;Y5];
% X=[X1;X2;X3;X4;X5];

Y=[Y1(1:end-1,:);Y2(1:end-1,:);Y3(1:end-1,:);Y4(1:end-1,:)];%;Y5(1:end-1,:)];
X=[X1(1:end-1,:);X2(1:end-1,:);X3(1:end-1,:);X4(1:end-1,:)];%X5(1:end-1,:)];

t=[t1(1:end-1) t2(1:end-1,:) t3(1:end-1,:) t4(1:end-1,:)];% t5(1:end-1,:)];

% plot(t,X)

%% open loop response
t1=0:0.1:4;
[Y1_ol, Tsim1_ol, X1_ol]=lsim(sys{1},w(1:41,:),t1);

t2=4.0:0.1:6;
X2_ol = [];
x_init = X1_ol(end,:);

sigma_t = sigma(27,:);
for i = 1:21  
    for i=1:5
        if sigma_t(i)==2
            x_init(3*i-2) = X1_ol(end,3*i-2);
        end
    end
    [Y2_ol, Tsim2_ol, X2_temp]=lsim(sys{1},w(40+i:41+i,:),[0 0.1],x_init);
    X2_ol = [X2_ol; X2_temp(end,:)];
    x_init = X2_temp(end,:);
end

t3=6.0:0.1:12;

X3_ol = [];
x_init = X2_ol(end,:);
sigma_t = sigma(32,:);
for i = 1:61  
    for i=1:5
        if sigma_t(i)==2
            x_init(3*i-2) = X2_ol(end,3*i-2);
        end
    end
    [Y3_ol, Tsim3_ol, X3_temp]=lsim(sys{1},w(50+i:51+i,:),[0 0.1],x_init);
    X3_ol = [X3_ol; X3_temp(end,:)];
    x_init = X3_temp(end,:);
end

for i=1:length(t3)-1
    X3_ol(i,2)=(X3_ol(i+1,1)-X3_ol(i,1))./(t3(i+1)-t3(i));
    X3_ol(i,5)=(X3_ol(i+1,4)-X3_ol(i,4))./(t3(i+1)-t3(i));
    X3_ol(i,8)=(X3_ol(i+1,7)-X3_ol(i,7))./(t3(i+1)-t3(i));
    X3_ol(i,11)=(X3_ol(i+1,10)-X3_ol(i,10))./(t3(i+1)-t3(i));
    X3_ol(i,14)=(X3_ol(i+1,13)-X3_ol(i,13))./(t3(i+1)-t3(i));
end


t4=12.0:0.1:25;
X4_ol = [];
x_init = X3_ol(end,:);
sigma_t = sigma(1,:);
for i = 1:131  
    for i=1:5
        if sigma_t(i)==2
            x_init(3*i-2) = X3_ol(end,3*i-2);
        end
    end
    [Y4_ol, Tsim4_ol, X4_temp]=lsim(sys{1},w(80+i:81+i,:),[0 0.1],x_init);
    X4_ol = [X4_ol; X4_temp(end,:)];
    x_init = X4_temp(end,:);
end

for i=1:length(t4)-1
    X4_ol(i,2)=(X4_ol(i+1,1)-X4_ol(i,1))./(t4(i+1)-t4(i));
    X4_ol(i,5)=(X4_ol(i+1,4)-X4_ol(i,4))./(t4(i+1)-t4(i));
    X4_ol(i,8)=(X4_ol(i+1,7)-X4_ol(i,7))./(t4(i+1)-t4(i));
    X4_ol(i,11)=(X4_ol(i+1,10)-X4_ol(i,10))./(t4(i+1)-t4(i));
    X4_ol(i,14)=(X4_ol(i+1,13)-X4_ol(i,13))./(t4(i+1)-t4(i));
end


Y_ol=[Y1_ol(1:end-1,:);Y2_ol(1:end-1,:);Y3_ol(1:end-1,:);Y4_ol(1:end-1,:)];%Y5_ol(1:end-1,:)];
X_ol=[X1_ol(1:end-1,:);X2_ol(1:end-1,:);X3_ol(1:end-1,:);X4_ol(1:end-1,:)];%X5_ol(1:end-1,:)];

t=[t1(1:end-1) t2(1:end-1) t3(1:end-1) t4(1:end-1)];% t5(1:end-1)];
figure

% t1=0:0.1:4;
% [Y1_ol, Tsim1, X1_ol]=lsim(sys{1},w(1:41,:),t1);
% t2=4.0:0.1:6;
% [Y2_ol, Tsim2, X2_ol]=lsim(sys{1},w(41:61,:),t2,X1_ol(end,:));
% t3=6.0:0.1:12;
% [Y3_ol, Tsim3, X3_ol]=lsim(sys{1},w(61:121,:),t3,X2_ol(end,:));
% t4=12.0:0.1:25;
% [Y4_ol, Tsim4, X4_ol]=lsim(sys{1},w(121:251,:),t4,X3_ol(end,:));
% 
% Y_ol=[Y1_ol(1:end-1,:);Y2_ol(1:end-1,:);Y3_ol(1:end-1,:);Y4_ol(1:end-1,:)];%Y5_ol(1:end-1,:)];
% X_ol=[X1_ol(1:end-1,:);X2_ol(1:end-1,:);X3_ol(1:end-1,:);X4_ol(1:end-1,:)];%X5_ol(1:end-1,:)];
% 
% t=[t1(1:end-1) t2(1:end-1) t3(1:end-1) t4(1:end-1)];% t5(1:end-1)];
%%
%e = 4*ones(1,length());
figure(1)
plot(t,X_ol(:,1),'-.','LineWidth',1.5)
hold on
plot(t,X(:,1),'LineWidth',1.5)
pl1 = line(4*ones(1,7),(-0.1:0.1:0.5));
pl1.Color = 'green';
pl1.LineStyle = '--';
pl1 = line(12*ones(1,7),(-0.1:0.1:0.5));
pl1.Color = 'green';
pl1.LineStyle = '--';
% pl2 = line(5*ones(1,7),(-0.1:0.1:0.5));
% pl2.Color = 'black';
% pl2.LineStyle = '-';
% pl2 = line(8*ones(1,7),(-0.1:0.1:0.5));
% pl2.Color = 'black';
% pl2.LineStyle = '-';
%title('Angle (Microgrid-1)')
ylim([-0.1 0.5])
ylabel('\Delta\delta_1(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

omega_1=diff(X(:,1))/0.1;

figure(2)
plot(t,X_ol(:,4),'-.','LineWidth',1.5)
hold on
plot(t,X(:,4),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
%title('Angle (Microgrid-2)')
ylim([-0.1 0.5])
ylabel('\Delta\delta_2(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(3)
plot(t,X_ol(:,7),'-.','LineWidth',1.5)
hold on
plot(t,X(:,7),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
%title('Angle (Microgrid-3)')
ylim([-0.1 0.5])
ylabel('\Delta\delta_3(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(4)
plot(t,X_ol(:,10),'-.','LineWidth',1.5)
hold on
plot(t,X(:,10),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
%title('Angle (Microgrid-3)')
ylim([-0.1 0.5])
ylabel('\Delta\delta_4(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(5)
plot(t,X_ol(:,13),'-.','LineWidth',1.5)
hold on
plot(t,X(:,13),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
%title('Angle (Microgrid-3)')
ylim([-0.1 0.5])
ylabel('\Delta\delta_5(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(6)
% plot(t,X_ol(:,2))
% hold on
plot(t,X(:,2),'r','LineWidth',1.5)
pl = line(4*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
%title('Frequency (Microgrid-1)')
ylim([-0.3 0.5])
ylabel('\Delta\omega_1(p.u.)')
xlabel('Time (sec)')
%legend('MAFD')

figure(7)
% plot(t,X_ol(:,5))
% hold on
plot(t,X(:,5),'r','LineWidth',1.5)
pl = line(4*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.3 0.5])
ylabel('\Delta\omega_2(p.u.)')
xlabel('Time (sec)')
%legend('MAFD')
%title('Frequency (Microgrid-2)')


figure(8)
% plot(t,X_ol(:,8))
% hold on
plot(t,X(:,8),'r','LineWidth',1.5)
pl = line(4*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.3 0.5])
ylabel('\Delta\omega_3(p.u.)')
xlabel('Time (sec)')
%legend('MAFD')
%title('Frequency (Microgrid-3)')

figure(9)
% plot(t,X_ol(:,8))
% hold on
plot(t,X(:,11),'r','LineWidth',1.5)
pl = line(4*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.3 0.5])
ylabel('\Delta\omega_4(p.u.)')
xlabel('Time (sec)')
%legend('MAFD')
%title('Frequency (Microgrid-3)')

figure(10)
% plot(t,X_ol(:,8))
% hold on
plot(t,X(:,14),'r','LineWidth',1.5)
pl = line(4*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,9),(-0.3:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.3 0.5])
ylabel('\Delta\omega_5(p.u.)')
xlabel('Time (sec)')
%legend('MAFD')
%title('Frequency (Microgrid-3)')

figure(11)
plot(t,X_ol(:,3),'-.','LineWidth',1.5)
hold on
plot(t,X(:,3),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.1 0.5])
ylabel('\Delta V_1(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-1)')

figure(12)
plot(t,X_ol(:,6),'-.','LineWidth',1.5)
hold on
plot(t,X(:,6),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
% pl2 = line(5*ones(1,7),(-0.1:0.1:0.5));
% pl2.Color = 'black';
% pl2.LineStyle = '-';
% pl2 = line(8*ones(1,7),(-0.1:0.1:0.5));
% pl2.Color = 'black';
% pl2.LineStyle = '-';
ylim([-0.1 0.5])
ylabel('\Delta V_2(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-2)')

figure(13)
plot(t,X_ol(:,9),'-.','LineWidth',1.5)
hold on
plot(t,X(:,9),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.1 0.5])
ylabel('\Delta V_3(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-3)')

figure(14)
plot(t,X_ol(:,12),'-.','LineWidth',1.5)
hold on
plot(t,X(:,12),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.1 0.5])
ylabel('\Delta V_4(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-3)')

figure(15)
plot(t,X_ol(:,15),'-.','LineWidth',1.5)
hold on
plot(t,X(:,15),'LineWidth',1.5)
pl = line(4*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
pl = line(12*ones(1,7),(-0.1:0.1:0.5));
pl.Color = 'green';
pl.LineStyle = '--';
ylim([-0.1 0.5])
ylabel('\Delta V_5(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-3)')