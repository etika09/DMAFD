clear all
close all
m = 5; %number of microgrids
sigma_i = [1 2]; %mode nummbers in each microgrid (this is \sigma_i from the paper)
n_m = 2; %number of switching modes for each microgrid 
sigma = combvec(sigma_i,sigma_i,sigma_i,sigma_i,sigma_i)'; %matrix with all possible values of sigma. Each row is a sigma.

% sigma = zeros(size(pre_final));
%  for i=1:m
%      sigma(:,i)=pre_final(:,m-i+1); 
%  end
num_out = 2*m; % number of outputs for interconnected grid
num_states = 3*m; % number of states for interconnected grid
[n,no_use] = size(sigma); % number of modes for interconnected grid

Jt = [8 12 12 9 10];
Dt = [2.3556 2.2000 2.3556 2.3556 2.0800];
Jw = 1*[8 12 12 9 10];
Dw = 1*[2.3556 2.2000 2.3556 2.3556 2.0800];
Jv = [12.9 10.200 11.5556 10.8333 11.7273];
Dv = [2.5 2 2.2222 2.0833 2.2727];
%% System Matrices
load('Jacobian_5bus.mat')

for i=1:m
    for j=1:n_m
        if j==1
            Am{i,j} = [-Dt(i)/Jt(i) 0 0;
                        Dt(i)^2/Jt(i)^2 0 0;
                        0 0 -Dv(i)/Jv(i)];
            B1m{i,j} = [-1/Jt(i) 0;
                        Dt(i)/Jt(i)^2 0;
                        0 -1/Jv(i)];
            B2m{i,j} = -B1m{i,j};
            Cm{i,j} = [1 0 0;
                       0 0 1];
            Dm{i,j} = zeros(2);
%            Dm{i,j} = 0.001*eye(2);
        end
        if j==2
            Am{i,j} = [0 1 0;
                       0 -Dw(i)/Jw(i) 0;
                        0 0 -Dv(i)/Jv(i)];
            B1m{i,j} = [0 0;
                        -1/Jw(i) 0;
                        0 -1/Jv(i)];
            B2m{i,j} = -B1m{i,j};
            Cm{i,j} = [0 1 0;
                       0 0 1];
            Dm{i,j} = zeros(2);
           % Dm{i,j} = 0.001*eye(2);
        end
    end
end
% Interconnected microgrid
L = zeros(3*m,3*m);
for i=1:m
    L(3*i-1,:)= H(2*i-1,:);
end
for i = 1:n
    A{i} = zeros(3*m,3*m);
    B1{i} = zeros(3*m,2*m);
    B2{i} = zeros(3*m,2*m);
    C{i} = zeros(2*m,3*m);
    D{i} = zeros(2*m,2*m);
    
    A_temp = zeros(3*m);
    B1_temp = zeros(3*m,2*m);
    B2_temp = zeros(3*m,2*m);
    C_temp = zeros(2*m,3*m);
    D_temp = zeros(2*m,2*m);
    J_temp = zeros(3*m,3*m);
    
    for j = 1:m
        A_temp((3*j-2):(3*j),(3*j-2):(3*j)) = Am{j,sigma(i,j)}; 
        B1_temp((3*j-2):(3*j),(2*j-1):(2*j)) = B1m{j,sigma(i,j)};
        B2_temp((3*j-2):(3*j),(2*j-1):(2*j)) = B2m{j,sigma(i,j)};
        C_temp((2*j-1):(2*j),(3*j-2):(3*j)) = Cm{j,sigma(i,j)};
        D_temp((2*j-1):(2*j),(2*j-1):(2*j)) = Dm{j,sigma(i,j)};
        if sigma(i,j) == 1
            J_temp(3*j-1,3*j-1) = -1/Jt(j);
        end
    end
    A_temp = A_temp + J_temp*L*A_temp;
    B1_temp = B1_temp + J_temp*L*B1_temp;
    B2_temp = B2_temp + J_temp*L*B2_temp;
    
    A{i} = A_temp; %+B1_temp*H; 
    B1{i} = B1_temp;
    B2{i} = B2_temp;
    C{i} = C_temp;
    D{i} = D_temp;
end
save('system_matrix_open_loop_5bus_3.mat','A','B1','B2','C','D')

for i=1:n
    A{i} = A{i}+B1{i}*H; 
end

%% QSR Values
for i=1:n
%     Q{i} = -0.1*eye(num_out); % Working values for ALL microgrids in angle mode
%     S{i} = 0.5*eye(num_out); % Working values for ALL microgrids in angle mode
%     R{i} = 0.15*eye(num_out); % Working values for ALL microgrids in angle mode
%     Q{i} = -0.001*eye(num_out); % Working values for ALL microgrids in angle mode
%     S{i} = 0.5*eye(num_out); % Working values for ALL microgrids in angle mode
%     R{i} = 0.15*eye(num_out); % Working values for ALL microgrids in angle mode
Q{i} = sdpvar(num_out);
S{i} = 0.5*eye(num_out);
R{i} = sdpvar(num_out);
end
% Q{2} = 0;
% S{2} = 0.5*eye(1);
% R{2} = 0.1*eye(1);
% Q{3} = 0;
% S{3} = 0.5*eye(1);
% R{3} = 0.1*eye(1);
% Q{4} = 0;
% S{4} = 0.5*eye(1);
% R{4} = 0.1*eye(1);

%% LMI
I = eye(num_out); %dim = number of outputs
P = sdpvar(num_states); %dim = number of states
%% LMI
struc = (H~=0);
struc(:,3*[1:5]-ones(1,5))=[];

I = eye(num_out); %dim = number of outputs
%%
for i=1:n
%     U{i} = sdpvar(num_out,num_out);
    U{i} = blkvar;
    for j = 1:size(struc,1)
        for k = 1:size(struc,2)
            if struc(j,k)==1
                U{i}(j,k) = 1*sdpvar(1);
            else
                U{i}(j,k) = 0;
            end
        end
    end
    U{i} = sdpvar(U{i});
    V{i} = sdpvar(num_out,num_out,'diagonal');
end

F = [P>0];%+ [Q{1}<0.0001*eye(size(Q{1}))];
%P=value(P);
for j=1:n
    %Q_{j} = sqrtm(-Q{j});
    Q_{j} = -Q{j};
    E = [-P*A{j}-A{j}'*P-B1{j}*U{j}*C{j}-C{j}'*U{j}'*B1{j}'  C{j}'*S{j}-P*B2{j}-B1{j}*U{j}*D{j}  -C{j}'*Q_{j};
        S{j}'*C{j}-B2{j}'*P-D{j}'*U{j}'*B1{j}'                D{j}'*S{j}+S{j}'*D{j}+R{j}         -D{j}'*Q_{j};
        -Q_{j}*C{j}                                           -Q_{j}*D{j}                         I];
    %obj=obj+P*B1{j}-B1{j}*V{j};
    F = F + [E>=-0.009*eye(size(E))]+ [P*B1{j}==B1{j}*V{j}]+[Q{j}<0.0001*eye(size(Q{j}))];
%
end
opt=sdpsettings('solver','sedumi')
solvesdp(F,[])
 for j=1:n
 K{j}=1e-4*inv(value(V{j}))*(value(U{j}));
sys{j}=ss(A{j}+B1{j}*1*K{j}*C{j},B2{j},C{j},D{j});
sys_ol{j}=ss(A{j},B2{j},C{j},D{j});
% figure
% %lsim(sys{j},zeros(100,6),0:1:99,[0.05;0.05;0.05;0;0.05;0.05;0.05;0.05;0.05])
% w=[zeros(50,6);repmat([0.15 0.15 0.15 0.15 0.15 0.15],30,1);zeros(120,6)];%2*[0.05 0.05 0.05 0.05 0.05 0.05];2*[0.05 0.05 0.05 0.05 0.05 0.05];zeros(42,6)];
% [Y, Tsim, X]=lsim(sys{j},w,0:0.1:19.9);%,[0;0;0;0;0;0;0;0;0])
% lsim(sys{j},w,0:0.1:19.9);
Q_{j}=-value(Q{j});
R{j}=value(R{j});
 end
 save('controllers_5bus_test_3.mat','K')
 save('closed_loop_5bus_test_3.mat','sys')
 save('open_loop_5bus_test_3.mat','sys_ol')