clear;
clc;
% %% Sequence impedance and admittance of distribution lines
% k=1000;
% M=k*k;
% Vb=12.66*k;% 12.66 kV
% Sb=M;% 1 kVA
% Zb=Vb^2/Sb;
V0 = [1;1.0028;0.9996;1.0031;0.9989];
theta0 = [0*pi/180;0.2329*pi/180;0.1104*pi/180;0.1582*pi/180;0.0518*pi/180];

%% Admittance matrix
z14=0.0054+1i*0.0050;
z23=0.0053+1i*0.0046;
z24=0.0125+1i*0.0125;
z35=0.0031+1i*0.0031;
z15=0.0013+1i*0.0006;

% Admittance matrix
Y14=-1/z14;
Y41=-1/z14;
Y23=-1/z23;
Y32=-1/z23;
Y24=-1/z24;
Y42=-1/z24;
Y35=-1/z35;
Y53=-1/z35;
Y15=-1/z15;
Y51=-1/z15;

Y11=-Y14-Y15;
Y22=-Y24-Y23;
Y33=-Y23-Y35;
Y44=-Y14-Y24;
Y55=-Y15-Y35;

Y_i=[Y11 0 0 Y14  Y15;
    0 Y22 Y23 Y24 0;
    0  Y23 Y33 0 Y35;
    Y41 Y42 0 Y44 0
    Y51 0 Y53 0 Y55];
G=real(Y_i);
B=imag(Y_i);
P=zeros(5,1);
Q=zeros(5,1);

for i=1:1:5
    for k=1:1:5
    P(i)=P(i)+V0(i)*V0(k)*(G(i,k)*cos(theta0(i)-theta0(k))+B(i,k)*sin(theta0(i)-theta0(k)));
    Q(i)=Q(i)+V0(i)*V0(k)*(G(i,k)*sin(theta0(i)-theta0(k))-B(i,k)*cos(theta0(i)-theta0(k)));
    end
end

%% Computing Jacobian
m= 5; % number of microgrids
for i=1:m
    for j=1:m
        H11=0;
        H12=0;
        H13 =0;
        H21=0;
        H22=0;
        H23 =0;
        if j==i
            H11 =-Q(j)-B(j,j)*V0(j)^2;
            H13 =P(j)/V0(j)+G(j,j)*V0(j);
            H12 = 0;
            H21=P(j)-G(j,j)*V0(j)^2;
            H23=Q(j)/V0(j)-B(j,j)*V0(j);
            H22 = 0;
        else
            H11=V0(i)*V0(j)*(G(i,j)*sin(theta0(i)-theta0(j))-B(i,j)*cos(theta0(i)-theta0(j)));
            H13=V0(i)*(G(i,j)*cos(theta0(i)-theta0(j))+B(i,j)*sin(theta0(i)-theta0(j)));
            H12 = 0;
            H21=-V0(i)*V0(j)*(G(i,j)*cos(theta0(i)-theta0(j))+B(i,j)*sin(theta0(i)-theta0(j)));           
            H23=V0(i)*(G(i,j)*sin(theta0(i)-theta0(j))-B(i,j)*cos(theta0(i)-theta0(j)));
            H22 = 0;
        end
        H((2*i-1):(2*i),(3*j-2):(3*j))=[H11 H12 H13;
                                        H21 H22 H23];
    end
end
% Jn=[J(:,1) J(:,4) J(:,2) J(:,5) J(:,3) J(:,6)];
% Jn=[Jn(1,:);Jn(4,:);Jn(2,:);Jn(5,:);Jn(3,:);Jn(6,:)];
% N=-(Jn'+Jn)/2;
% e=max(eig(N));
save('Jacobian_5bus.mat','H')