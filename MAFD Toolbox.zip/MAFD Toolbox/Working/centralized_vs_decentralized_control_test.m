clear all
close all
load('controllers_5bus.mat')
load('system_matrix_open_loop_5bus.mat')
m = 5; %number of microgrids
sigma_i = [1 2]; %mode nummbers in each microgrid (this is \sigma_i from the paper)
n_m = 2; %number of switching modes for each microgrid 
sigma = combvec(sigma_i,sigma_i,sigma_i,sigma_i,sigma_i)'; %matrix with all possible values of sigma. Each row is a sigma.
%% centralized control
status = 1;
mode1=1;
[Tsim1_cn, X1_cn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode1}, B1{mode1}, B2{mode1}, C{mode1}, D{mode1}, K{mode1},sigma(mode1,:),C{mode1}*zeros(15,1),status),[0:0.1:4],zeros(15,1));
for i=1:length(Tsim1_cn)-1
    X1_cn(i,2)=(X1_cn(i+1,1)-X1_cn(i,1))./(Tsim1_cn(i+1)-Tsim1_cn(i));
    X1_cn(i,5)=(X1_cn(i+1,4)-X1_cn(i,4))./(Tsim1_cn(i+1)-Tsim1_cn(i));
    X1_cn(i,8)=(X1_cn(i+1,7)-X1_cn(i,7))./(Tsim1_cn(i+1)-Tsim1_cn(i));
    X1_cn(i,11)=(X1_cn(i+1,10)-X1_cn(i,10))./(Tsim1_cn(i+1)-Tsim1_cn(i));
    X1_cn(i,14)=(X1_cn(i+1,13)-X1_cn(i,13))./(Tsim1_cn(i+1)-Tsim1_cn(i));
end
mode2 = 27;
[Tsim2_cn, X2_cn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode2}, B1{mode2}, B2{mode2}, C{mode2}, D{mode2}, K{mode2},sigma(mode2,:),C{mode2}*X1_cn(end-1,:)',status),[3.9:0.1:11],X1_cn(end-1,:));
for i=1:length(Tsim2_cn)-1
    X2_cn(i,2)=(X2_cn(i+1,1)-X2_cn(i,1))./(Tsim2_cn(i+1)-Tsim2_cn(i));
    X2_cn(i,5)=(X2_cn(i+1,4)-X2_cn(i,4))./(Tsim2_cn(i+1)-Tsim2_cn(i));
    X2_cn(i,8)=(X2_cn(i+1,7)-X2_cn(i,7))./(Tsim2_cn(i+1)-Tsim2_cn(i));
    X2_cn(i,11)=(X2_cn(i+1,10)-X2_cn(i,10))./(Tsim2_cn(i+1)-Tsim2_cn(i));
    X2_cn(i,14)=(X2_cn(i+1,13)-X2_cn(i,13))./(Tsim2_cn(i+1)-Tsim2_cn(i));
end
mode3=32;
[Tsim3_cn, X3_cn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode3}, B1{mode3}, B2{mode3}, C{mode3}, D{mode3}, K{mode3},sigma(mode3,:),C{mode3}*X2_cn(end-1,:)',status),[10.9:0.1:12],X2_cn(end-1,:));
for i=1:length(Tsim3_cn)-1
    X3_cn(i,2)=(X3_cn(i+1,1)-X3_cn(i,1))./(Tsim3_cn(i+1)-Tsim3_cn(i));
    X3_cn(i,5)=(X3_cn(i+1,4)-X3_cn(i,4))./(Tsim3_cn(i+1)-Tsim3_cn(i));
    X3_cn(i,8)=(X3_cn(i+1,7)-X3_cn(i,7))./(Tsim3_cn(i+1)-Tsim3_cn(i));
    X3_cn(i,11)=(X3_cn(i+1,10)-X3_cn(i,10))./(Tsim3_cn(i+1)-Tsim3_cn(i));
    X3_cn(i,14)=(X3_cn(i+1,13)-X3_cn(i,13))./(Tsim3_cn(i+1)-Tsim3_cn(i));
end
mode4 = 5;
[Tsim4_cn, X4_cn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode4}, B1{mode4}, B2{mode4}, C{mode4}, D{mode4}, K{mode4},sigma(mode4,:),C{mode4}*X3_cn(end-1,:)',status),[11.9:0.1:18],X3_cn(end-1,:));
for i=1:length(Tsim4_cn)-1
    X4_cn(i,2)=(X4_cn(i+1,1)-X4_cn(i,1))./(Tsim4_cn(i+1)-Tsim4_cn(i));
    X4_cn(i,5)=(X4_cn(i+1,4)-X4_cn(i,4))./(Tsim4_cn(i+1)-Tsim4_cn(i));
    X4_cn(i,8)=(X4_cn(i+1,7)-X4_cn(i,7))./(Tsim4_cn(i+1)-Tsim4_cn(i));
    X4_cn(i,11)=(X4_cn(i+1,10)-X4_cn(i,10))./(Tsim4_cn(i+1)-Tsim4_cn(i));
    X4_cn(i,14)=(X4_cn(i+1,13)-X4_cn(i,13))./(Tsim4_cn(i+1)-Tsim4_cn(i));
end
mode5 = 1;
[Tsim5_cn, X5_cn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode5}, B1{mode5}, B2{mode5}, C{mode5}, D{mode5}, K{mode5},sigma(mode5,:),C{mode5}*X4_cn(end-1,:)',status),[17.9:0.1:25],X4_cn(end-1,:));
for i=1:length(Tsim5_cn)-1
    X5_cn(i,2)=(X5_cn(i+1,1)-X5_cn(i,1))./(Tsim5_cn(i+1)-Tsim5_cn(i));
    X5_cn(i,5)=(X5_cn(i+1,4)-X5_cn(i,4))./(Tsim5_cn(i+1)-Tsim5_cn(i));
    X5_cn(i,8)=(X5_cn(i+1,7)-X5_cn(i,7))./(Tsim5_cn(i+1)-Tsim5_cn(i));
    X5_cn(i,11)=(X5_cn(i+1,10)-X5_cn(i,10))./(Tsim5_cn(i+1)-Tsim5_cn(i));
    X5_cn(i,14)=(X5_cn(i+1,13)-X5_cn(i,13))./(Tsim5_cn(i+1)-Tsim5_cn(i));
end

X_cn=[X1_cn(1:end-1,:);X2_cn(2:end-1,:);X3_cn(2:end-1,:);X4_cn(2:end-1,:);X5_cn(2:end-1,:)];
t_cn=[Tsim1_cn(1:end-1);Tsim2_cn(2:end-1);Tsim3_cn(2:end-1);Tsim4_cn(2:end-1);Tsim5_cn(2:end-1)];
%% decentralized control
load('controllers_5bus_test_working.mat')
status = 1;
mode1=1;
[Tsim1_dcn, X1_dcn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode1}, B1{mode1}, B2{mode1}, C{mode1}, D{mode1}, K{mode1},sigma(mode1,:),C{mode1}*zeros(15,1),status),[0:0.1:4],zeros(15,1));
for i=1:length(Tsim1_dcn)-1
    X1_dcn(i,2)=(X1_dcn(i+1,1)-X1_dcn(i,1))./(Tsim1_dcn(i+1)-Tsim1_dcn(i));
    X1_dcn(i,5)=(X1_dcn(i+1,4)-X1_dcn(i,4))./(Tsim1_dcn(i+1)-Tsim1_dcn(i));
    X1_dcn(i,8)=(X1_dcn(i+1,7)-X1_dcn(i,7))./(Tsim1_dcn(i+1)-Tsim1_dcn(i));
    X1_dcn(i,11)=(X1_dcn(i+1,10)-X1_dcn(i,10))./(Tsim1_dcn(i+1)-Tsim1_dcn(i));
    X1_dcn(i,14)=(X1_dcn(i+1,13)-X1_dcn(i,13))./(Tsim1_dcn(i+1)-Tsim1_dcn(i));
end
mode2 = 27;
[Tsim2_dcn, X2_dcn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode2}, B1{mode2}, B2{mode2}, C{mode2}, D{mode2}, K{mode2},sigma(mode2,:),C{mode2}*X1_dcn(end-1,:)',status),[3.9:0.1:11],X1_dcn(end-1,:));
for i=1:length(Tsim2_dcn)-1
    X2_dcn(i,2)=(X2_dcn(i+1,1)-X2_dcn(i,1))./(Tsim2_dcn(i+1)-Tsim2_dcn(i));
    X2_dcn(i,5)=(X2_dcn(i+1,4)-X2_dcn(i,4))./(Tsim2_dcn(i+1)-Tsim2_dcn(i));
    X2_dcn(i,8)=(X2_dcn(i+1,7)-X2_dcn(i,7))./(Tsim2_dcn(i+1)-Tsim2_dcn(i));
    X2_dcn(i,11)=(X2_dcn(i+1,10)-X2_dcn(i,10))./(Tsim2_dcn(i+1)-Tsim2_dcn(i));
    X2_dcn(i,14)=(X2_dcn(i+1,13)-X2_dcn(i,13))./(Tsim2_dcn(i+1)-Tsim2_dcn(i));
end
mode3=32;
[Tsim3_dcn, X3_dcn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode3}, B1{mode3}, B2{mode3}, C{mode3}, D{mode3}, K{mode3},sigma(mode3,:),C{mode3}*X2_dcn(end-1,:)',status),[10.9:0.1:12],X2_dcn(end-1,:));
for i=1:length(Tsim3_dcn)-1
    X3_dcn(i,2)=(X3_dcn(i+1,1)-X3_dcn(i,1))./(Tsim3_dcn(i+1)-Tsim3_dcn(i));
    X3_dcn(i,5)=(X3_dcn(i+1,4)-X3_dcn(i,4))./(Tsim3_dcn(i+1)-Tsim3_dcn(i));
    X3_dcn(i,8)=(X3_dcn(i+1,7)-X3_dcn(i,7))./(Tsim3_dcn(i+1)-Tsim3_dcn(i));
    X3_dcn(i,11)=(X3_dcn(i+1,10)-X3_dcn(i,10))./(Tsim3_dcn(i+1)-Tsim3_dcn(i));
    X3_dcn(i,14)=(X3_dcn(i+1,13)-X3_dcn(i,13))./(Tsim3_dcn(i+1)-Tsim3_dcn(i));
end
mode4 = 5;
[Tsim4_dcn, X4_dcn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode4}, B1{mode4}, B2{mode4}, C{mode4}, D{mode4}, K{mode4},sigma(mode4,:),C{mode4}*X3_dcn(end-1,:)',status),[11.9:0.1:18],X3_dcn(end-1,:));
for i=1:length(Tsim4_dcn)-1
    X4_dcn(i,2)=(X4_dcn(i+1,1)-X4_dcn(i,1))./(Tsim4_dcn(i+1)-Tsim4_dcn(i));
    X4_dcn(i,5)=(X4_dcn(i+1,4)-X4_dcn(i,4))./(Tsim4_dcn(i+1)-Tsim4_dcn(i));
    X4_dcn(i,8)=(X4_dcn(i+1,7)-X4_dcn(i,7))./(Tsim4_dcn(i+1)-Tsim4_dcn(i));
    X4_dcn(i,11)=(X4_dcn(i+1,10)-X4_dcn(i,10))./(Tsim4_dcn(i+1)-Tsim4_dcn(i));
    X4_dcn(i,14)=(X4_dcn(i+1,13)-X4_dcn(i,13))./(Tsim4_dcn(i+1)-Tsim4_dcn(i));
end
mode5 = 1;
[Tsim5_dcn, X5_dcn]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode5}, B1{mode5}, B2{mode5}, C{mode5}, D{mode5}, K{mode5},sigma(mode5,:),C{mode5}*X4_dcn(end-1,:)',status),[17.9:0.1:25],X4_dcn(end-1,:));
for i=1:length(Tsim5_dcn)-1
    X5_dcn(i,2)=(X5_dcn(i+1,1)-X5_dcn(i,1))./(Tsim5_dcn(i+1)-Tsim5_dcn(i));
    X5_dcn(i,5)=(X5_dcn(i+1,4)-X5_dcn(i,4))./(Tsim5_dcn(i+1)-Tsim5_dcn(i));
    X5_dcn(i,8)=(X5_dcn(i+1,7)-X5_dcn(i,7))./(Tsim5_dcn(i+1)-Tsim5_dcn(i));
    X5_dcn(i,11)=(X5_dcn(i+1,10)-X5_dcn(i,10))./(Tsim5_dcn(i+1)-Tsim5_dcn(i));
    X5_dcn(i,14)=(X5_dcn(i+1,13)-X5_dcn(i,13))./(Tsim5_dcn(i+1)-Tsim5_dcn(i));
end

X_dcn=[X1_dcn(1:end-1,:);X2_dcn(2:end-1,:);X3_dcn(2:end-1,:);X4_dcn(2:end-1,:);X5_dcn(2:end-1,:)];
t_dcn=[Tsim1_dcn(1:end-1);Tsim2_dcn(2:end-1);Tsim3_dcn(2:end-1);Tsim4_dcn(2:end-1);Tsim5_dcn(2:end-1)];
%%
%e = 4*ones(1,length());
figure(1)
plot(t_cn,X_cn(:,1),'-.','LineWidth',1.5)
hold onX_cn
plot(t_dcn,X_dcn(:,1),'LineWidth',1.5)
% pl1 = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl1.Color = 'green';
% pl1.LineStyle = '--';
% pl1 = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl1.Color = 'green';
% pl1.LineStyle = '--';
ylabel('\Delta\delta_1(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(2)
plot(t_cn,X_cn(:,4),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,4),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
%title('Angle (Microgrid-2)')
% ylim([-0.1 0.5])
ylabel('\Delta\delta_2(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(3)
plot(t_cn,X_cn(:,7),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,7),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
%title('Angle (Microgrid-3)')
% ylim([-0.1 0.5])
ylabel('\Delta\delta_3(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(4)
plot(t_cn,X_cn(:,10),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,10),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
%title('Angle (Microgrid-3)')
% ylim([-0.1 0.5])
ylabel('\Delta\delta_4(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

figure(5)
plot(t_cn,X_cn(:,13),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,13),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
%title('Angle (Microgrid-3)')
% ylim([-0.1 0.5])
ylabel('\Delta\delta_5(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')

% figure(6)
% % plot(t_cn,X_cn(:,2))
% % hold on
% plot(t_dcn,X_dcn(:,2),'r','LineWidth',1.5)
% pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% %title('Frequency (Microgrid-1)')
% % ylim([-0.3 0.5])
% ylabel('\Delta\omega_1(p.u.)')
% xlabel('Time (sec)')
% %legend('MAFD')
% 
% figure(7)
% % plot(t_dcn,X_cn(:,5))
% % hold on
% plot(t_dcn,X_dcn(:,5),'r','LineWidth',1.5)
% pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% % ylim([-0.3 0.5])
% ylabel('\Delta\omega_2(p.u.)')
% xlabel('Time (sec)')
% %legend('MAFD')
% %title('Frequency (Microgrid-2)')
% 
% 
% figure(8)
% % plot(t_dcn,X_cn(:,8))
% % hold on
% plot(t_dcn,X_dcn(:,8),'r','LineWidth',1.5)
% pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% % ylim([-0.3 0.5])
% ylabel('\Delta\omega_3(p.u.)')
% xlabel('Time (sec)')
% %legend('MAFD')
% %title('Frequency (Microgrid-3)')
% 
% figure(9)
% % plot(t_dcn,X_cn(:,8))
% % hold on
% plot(t_dcn,X_dcn(:,11),'r','LineWidth',1.5)
% pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% % ylim([-0.3 0.5])
% ylabel('\Delta\omega_4(p.u.)')
% xlabel('Time (sec)')
% %legend('MAFD')
% %title('Frequency (Microgrid-3)')
% 
% figure(10)
% % plot(t_dcn,X_cn(:,8))
% % hold on
% plot(t_dcn,X_dcn(:,14),'r','LineWidth',1.5)
% pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% % ylim([-0.3 0.5])
% ylabel('\Delta\omega_5(p.u.)')
% xlabel('Time (sec)')
% %legend('MAFD')
% %title('Frequency (Microgrid-3)')

figure(11)
plot(t_cn,X_cn(:,3),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,3),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% ylim([-0.1 0.5])
ylabel('\Delta V_1(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-1)')

figure(12)
plot(t_cn,X_cn(:,6),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,6),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl2 = line(5*ones(1,7),(-0.1:0.1:0.5));
% pl2.Color = 'black';
% pl2.LineStyle = '-';
% pl2 = line(8*ones(1,7),(-0.1:0.1:0.5));
% pl2.Color = 'black';
% pl2.LineStyle = '-';
% ylim([-0.1 0.5])
ylabel('\Delta V_2(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-2)')

figure(13)
plot(t_cn,X_cn(:,9),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,9),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% ylim([-0.1 0.5])
ylabel('\Delta V_3(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-3)')

figure(14)
plot(t_cn,X_cn(:,12),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,12),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% ylim([-0.1 0.5])
ylabel('\Delta V_4(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-3)')

figure(15)
plot(t_cn,X_cn(:,15),'-.','LineWidth',1.5)
hold on
plot(t_dcn,X_dcn(:,15),'LineWidth',1.5)
% pl = line(4*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% pl = line(12*ones(1,7),(-0.1:0.1:0.5));
% pl.Color = 'green';
% pl.LineStyle = '--';
% ylim([-0.1 0.5])
ylabel('\Delta V_5(p.u.)')
xlabel('Time (sec)')
%legend('Angle droop control','MAFD')
%title('Voltage (Microgrid-3)')

% mode = sigma([mode1,mode1,mode2,mode2,mode3,mode3,mode4,mode4],:);%,mode7,mode7],:);
% T_mode = [Tsim1_dcn(1),Tsim1_dcn(end),Tsim1_dcn(end),Tsim2_dcn(end),Tsim2(end),Tsim3(end),Tsim3(end),Tsim4(end)];%,Tsim6(end),Tsim7(end)];
% figure(16)
% plot(T_mode,mode(:,1),'LineWidth', 3)
% hold on
% plot(T_mode,mode(:,2)+2,'LineWidth', 3)
% plot(T_mode,mode(:,3)+4,'LineWidth', 3)
% plot(T_mode,mode(:,4)+6,'LineWidth', 3)
% plot(T_mode,mode(:,5)+8,'LineWidth', 3)
% %mlabel('Microgrid 1','Microgrid 2', 'Microgrid 3', 'Microgrid 4', 'Microgrid 5')
% 
%%
filename = 'CENvsDECEN.xlsx';
for i =1:15
T{i} = table(t_cn,X_cn(:,i),X_dcn(:,i));
writetable(T{i},filename,'Sheet',i)
end