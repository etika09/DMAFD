clear all
close all
load('controllers_5bus_test_working_pert.mat')
load('system_matrix_open_loop_3to5_pert.mat')
load('system_matrix_open_loop_5bus.mat')
m = 5; %number of microgrids
sigma_i = [1 2]; %mode nummbers in each microgrid (this is \sigma_i from the paper)
n_m = 2; %number of switching modes for each microgrid 
sigma = combvec(sigma_i,sigma_i,sigma_i,sigma_i,sigma_i)'; %matrix with all possible values of sigma. Each row is a sigma.
for i=1:32
    K{i}=1e3*K{i};
end
%% closed loop response
status = 1;
mode1=1;
del_V0 = [1;1.00706404710539;1.00526534392652;1.00441884817844;0.998551675563331] - [1;1.0028;0.9996;1.0031;0.9989];
del_theta0 = [0;0.561094826028272;0.527505168319061;0.253129942345307;0.0386159910150195]*pi/180 - [0;0.2329;0.1104;0.1582;0.0518]*pi/180;
init = zeros(15,1);
for i =1:5
    init(3*i-2) = del_theta0(i);
    init(3*i) = del_V0(i);
end
[Tsim1, X1_out]=ode45(@(t,x)MAFD_dynamics_pert(t,x,A_pert{mode1}, B1_pert{mode1}, B2_pert{mode1}, C_pert{mode1}, D_pert{mode1}, K{mode1},sigma(mode1,:),C_pert{mode1}*init,status),[0:0.1:2],init);
for i=1:length(Tsim1)-1
    X1_out(i,2)=(X1_out(i+1,1)-X1_out(i,1))./(Tsim1(i+1)-Tsim1(i));
    X1_out(i,5)=(X1_out(i+1,4)-X1_out(i,4))./(Tsim1(i+1)-Tsim1(i));
    X1_out(i,8)=(X1_out(i+1,7)-X1_out(i,7))./(Tsim1(i+1)-Tsim1(i));
    X1_out(i,11)=(X1_out(i+1,10)-X1_out(i,10))./(Tsim1(i+1)-Tsim1(i));
    X1_out(i,14)=(X1_out(i+1,13)-X1_out(i,13))./(Tsim1(i+1)-Tsim1(i));
end

mode2 = 19;
[Tsim2, X2_out]=ode45(@(t,x)MAFD_dynamics_pert(t,x,A_pert{mode2}, B1_pert{mode2}, B2_pert{mode2}, C_pert{mode2}, D_pert{mode2}, K{mode2},sigma(mode2,:),C_pert{mode2}*X1_out(end-1,:)',status),[1.9:0.1:3],X1_out(end-1,:));
for i=1:length(Tsim2)-1
    X2_out(i,2)=(X2_out(i+1,1)-X2_out(i,1))./(Tsim2(i+1)-Tsim2(i));
    X2_out(i,5)=(X2_out(i+1,4)-X2_out(i,4))./(Tsim2(i+1)-Tsim2(i));
    X2_out(i,8)=(X2_out(i+1,7)-X2_out(i,7))./(Tsim2(i+1)-Tsim2(i));
    X2_out(i,11)=(X2_out(i+1,10)-X2_out(i,10))./(Tsim2(i+1)-Tsim2(i));
    X2_out(i,14)=(X2_out(i+1,13)-X2_out(i,13))./(Tsim2(i+1)-Tsim2(i));
end

mode3=19;
[Tsim3, X3_out]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode3}, B1{mode3}, B2{mode3}, C{mode3}, D{mode3}, K{mode3},sigma(mode3,:),C{mode3}*X2_out(end-1,:)',status),[2.9:0.1:5],X2_out(end-1,:));
for i=1:length(Tsim3)-1
    X3_out(i,2)=(X3_out(i+1,1)-X3_out(i,1))./(Tsim3(i+1)-Tsim3(i));
    X3_out(i,5)=(X3_out(i+1,4)-X3_out(i,4))./(Tsim3(i+1)-Tsim3(i));
    X3_out(i,8)=(X3_out(i+1,7)-X3_out(i,7))./(Tsim3(i+1)-Tsim3(i));
    X3_out(i,11)=(X3_out(i+1,10)-X3_out(i,10))./(Tsim3(i+1)-Tsim3(i));
    X3_out(i,14)=(X3_out(i+1,13)-X3_out(i,13))./(Tsim3(i+1)-Tsim3(i));
end

mode4 = 1;
[Tsim4, X4_out]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode4}, B1{mode4}, B2{mode4}, C{mode4}, D{mode4}, K{mode4},sigma(mode4,:),C{mode4}*X3_out(end-1,:)',status),[4.9:0.1:10],X3_out(end-1,:));
for i=1:length(Tsim4)-1
    X4_out(i,2)=(X4_out(i+1,1)-X4_out(i,1))./(Tsim4(i+1)-Tsim4(i));
    X4_out(i,5)=(X4_out(i+1,4)-X4_out(i,4))./(Tsim4(i+1)-Tsim4(i));
    X4_out(i,8)=(X4_out(i+1,7)-X4_out(i,7))./(Tsim4(i+1)-Tsim4(i));
    X4_out(i,11)=(X4_out(i+1,10)-X4_out(i,10))./(Tsim4(i+1)-Tsim4(i));
    X4_out(i,14)=(X4_out(i+1,13)-X4_out(i,13))./(Tsim4(i+1)-Tsim4(i));
end
% 
% mode5 = 1;
% [Tsim5, X5_out]=ode45(@(t,x)MAFD_dynamics(t,x,A{mode5}, B1{mode5}, B2{mode5}, C{mode5}, D{mode5}, K{mode5},sigma(mode5,:),C{mode5}*X4_out(end-1,:)',status),[24.9:0.1:40],X4_out(end-1,:));
% for i=1:length(Tsim5)-1
%     X5_out(i,2)=(X5_out(i+1,1)-X5_out(i,1))./(Tsim5(i+1)-Tsim5(i));
%     X5_out(i,5)=(X5_out(i+1,4)-X5_out(i,4))./(Tsim5(i+1)-Tsim5(i));
%     X5_out(i,8)=(X5_out(i+1,7)-X5_out(i,7))./(Tsim5(i+1)-Tsim5(i));
%     X5_out(i,11)=(X5_out(i+1,10)-X5_out(i,10))./(Tsim5(i+1)-Tsim5(i));
%     X5_out(i,14)=(X5_out(i+1,13)-X5_out(i,13))./(Tsim5(i+1)-Tsim5(i));
% end
% % 

X=[X1_out(1:end-1,:);X2_out(2:end-1,:);X3_out(2:end-1,:);X4_out(2:end-1,:)];%X5_out(2:end-1,:)];%X7_out(2:end-1,:)];

t=[Tsim1(1:end-1);Tsim2(2:end-1);Tsim3(2:end-1);Tsim4(2:end-1)];%Tsim5(2:end-1)];%Tsim7(2:end-1)];

% plot(t,X)

%% open loop response
% status = 0;
% [Tsim1_ol, X1_ol]=ode45(@(t,x)MAFD_dynamics_pert(t,x,A_pert{1}, B1_pert{1}, B2_pert{1}, C_pert{1}, D_pert{1}, K{1},sigma(mode1,:),C_pert{1}*init,status),[0:0.1:7],init);
% 
% % for i=1:length(Tsim1_ol)-1
% %     X1_ol(i,2)=(X1_ol(i+1,1)-X1_ol(i,1))./(Tsim1_ol(i+1)-Tsim1_ol(i));
% %     X1_ol(i,5)=(X1_ol(i+1,4)-X1_ol(i,4))./(Tsim1_ol(i+1)-Tsim1_ol(i));
% %     X1_ol(i,8)=(X1_ol(i+1,7)-X1_ol(i,7))./(Tsim1_ol(i+1)-Tsim1_ol(i));
% %     X1_ol(i,11)=(X1_ol(i+1,10)-X1_ol(i,10))./(Tsim1_ol(i+1)-Tsim1_ol(i));
% %     X1_ol(i,14)=(X1_ol(i+1,13)-X1_ol(i,13))./(Tsim1_ol(i+1)-Tsim1_ol(i));
% % end
% 
% [Tsim2_ol, X2_ol]=ode45(@(t,x)MAFD_dynamics_pert(t,x,A_pert{1}, B1_pert{1}, B2_pert{1}, C_pert{1}, D_pert{1}, K{1},sigma(mode2,:),C_pert{1}*X1_ol(end,:)',status),[6.9:0.1:8],X1_ol(end,:));
% [Tsim3_ol, X3_ol]=ode45(@(t,x)MAFD_dynamics(t,x,A{1}, B1{1}, B2{1}, C{1}, D{1}, K{1},sigma(mode3,:),C{1}*X2_ol(end,:)',status),[7.9:0.1:10],X2_ol(end,:));
% [Tsim4_ol, X4_ol]=ode45(@(t,x)MAFD_dynamics(t,x,A{1}, B1{1}, B2{1}, C{1}, D{1}, K{1},sigma(mode4,:),C{1}*X3_ol(end,:)',status),[9.9:0.1:15],X3_ol(end,:));
% % [Tsim5_ol, X5_ol]=ode45(@(t,x)MAFD_dynamics(t,x,A{1}, B1{1}, B2{1}, C{1}, D{1}, K{1},sigma(mode5,:),C{1}*X4_ol(end,:)',status),[24.9:0.1:40],X4_ol(end,:));
% 
% 
% X_ol=[X1_ol(1:end-1,:);X2_ol(2:end-1,:);X3_ol(2:end-1,:);X4_ol(2:end-1,:)];%X5_ol(2:end-1,:)];
% 
% t_ol=[Tsim1_ol(1:end-1);Tsim2_ol(2:end-1);Tsim3_ol(2:end-1);Tsim4_ol(2:end-1)];%Tsim5_ol(2:end-1)];
%%
%e = 4*ones(1,length());
figure(1)
% plot(t_ol,X_ol(:,1),'-.','LineWidth',1.5)
% hold on
plot(t,X(:,1),'LineWidth',1.5)
hold on
plot(t,X(:,4),'LineWidth',1.5)
plot(t,X(:,7),'LineWidth',1.5)
plot(t,X(:,10),'LineWidth',1.5)
plot(t,X(:,13),'LineWidth',1.5)
ylabel('\Delta\delta (p.u.)')
xlabel('Time (sec)')
% ylim([-0.2 0.9])

figure(2)
% plot(t_ol,X_ol(:,1),'-.','LineWidth',1.5)
% hold on
plot(t,X(:,3),'LineWidth',1.5)
hold on
plot(t,X(:,6),'LineWidth',1.5)
plot(t,X(:,9),'LineWidth',1.5)
plot(t,X(:,12),'LineWidth',1.5)
plot(t,X(:,15),'LineWidth',1.5)
ylabel('\Delta V (p.u.)')
xlabel('Time (sec)')
% ylim([-0.15 0.15])

% figure(2)
% % plot(t_ol,X_ol(:,4),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,4),'LineWidth',1.5)
% ylabel('\Delta\delta_2(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% 
% figure(3)
% % plot(t_ol,X_ol(:,7),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,7),'LineWidth',1.5)
% ylabel('\Delta\delta_3(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% 
% figure(4)
% % plot(t_ol,X_ol(:,10),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,10),'LineWidth',1.5)
% ylabel('\Delta\delta_4(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% 
% figure(5)
% % plot(t_ol,X_ol(:,13),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,13),'LineWidth',1.5)
% ylabel('\Delta\delta_5(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% 
% % figure(6)
% % % plot(t_ol,X_ol(:,2))
% % % hold on
% % plot(t,X(:,2),'r','LineWidth',1.5)
% % pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % %title('Frequency (Microgrid-1)')
% % % ylim([-0.3 0.5])
% % ylabel('\Delta\omega_1(p.u.)')
% % xlabel('Time (sec)')
% % %legend('MAFD')
% % 
% % figure(7)
% % % plot(t,X_ol(:,5))
% % % hold on
% % plot(t,X(:,5),'r','LineWidth',1.5)
% % pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % % ylim([-0.3 0.5])
% % ylabel('\Delta\omega_2(p.u.)')
% % xlabel('Time (sec)')
% % %legend('MAFD')
% % %title('Frequency (Microgrid-2)')
% % 
% % 
% % figure(8)
% % % plot(t,X_ol(:,8))
% % % hold on
% % plot(t,X(:,8),'r','LineWidth',1.5)
% % pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % % ylim([-0.3 0.5])
% % ylabel('\Delta\omega_3(p.u.)')
% % xlabel('Time (sec)')
% % %legend('MAFD')
% % %title('Frequency (Microgrid-3)')
% % 
% % figure(9)
% % % plot(t,X_ol(:,8))
% % % hold on
% % plot(t,X(:,11),'r','LineWidth',1.5)
% % pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % % ylim([-0.3 0.5])
% % ylabel('\Delta\omega_4(p.u.)')
% % xlabel('Time (sec)')
% % %legend('MAFD')
% % %title('Frequency (Microgrid-3)')
% % 
% % figure(10)
% % % plot(t,X_ol(:,8))
% % % hold on
% % plot(t,X(:,14),'r','LineWidth',1.5)
% % pl = line(4*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % pl = line(12*ones(1,9),(-0.3:0.1:0.5));
% % pl.Color = 'green';
% % pl.LineStyle = '--';
% % % ylim([-0.3 0.5])
% % ylabel('\Delta\omega_5(p.u.)')
% % xlabel('Time (sec)')
% % %legend('MAFD')
% % %title('Frequency (Microgrid-3)')
% 
% figure(11)
% % plot(t_ol,X_ol(:,3),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,3),'LineWidth',1.5)
% ylabel('\Delta V_1(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% %title('Voltage (Microgrid-1)')
% 
% figure(12)
% % plot(t_ol,X_ol(:,6),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,6),'LineWidth',1.5)
% ylabel('\Delta V_2(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% %title('Voltage (Microgrid-2)')
% 
% figure(13)
% % plot(t_ol,X_ol(:,9),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,9),'LineWidth',1.5)
% ylabel('\Delta V_3(p.u.)')
% xlabel('Time (sec)')
% 
% figure(14)
% % plot(t_ol,X_ol(:,12),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,12),'LineWidth',1.5)
% ylabel('\Delta V_4(p.u.)')
% xlabel('Time (sec)')
% 
% figure(15)
% % plot(t_ol,X_ol(:,15),'-.','LineWidth',1.5)
% % hold on
% plot(t,X(:,15),'LineWidth',1.5)
% ylabel('\Delta V_5(p.u.)')
% xlabel('Time (sec)')
% %legend('Angle droop control','MAFD')
% %title('Voltage (Microgrid-3)')

% mode = sigma([mode1,mode1,mode2,mode2,mode3,mode3,mode4,mode4],:);%,mode5,mode5,mode7,mode7],:);
% T_mode = [Tsim1(1),Tsim1(end),Tsim1(end),Tsim2(end),Tsim2(end),Tsim3(end),Tsim3(end),Tsim4(end),Tsim4(end)];%,Tsim5(end),Tsim6(end),Tsim7(end)];
% figure(16)
% plot(T_mode,mode(:,1),'LineWidth', 3)
% hold on
% plot(T_mode,mode(:,2)+2,'LineWidth', 3)
% plot(T_mode,mode(:,3)+4,'LineWidth', 3)
% plot(T_mode,mode(:,4)+6,'LineWidth', 3)
% plot(T_mode,mode(:,5)+8,'LineWidth', 3)
%mlabel('Microgrid 1','Microgrid 2', 'Microgrid 3', 'Microgrid 4', 'Microgrid 5')

%%
filename = 'DMAFD_robust_3to5_out.xlsx';
T1 = table(t,X(:,1),X(:,4),X(:,7),X(:,10),X(:,13));
T2 = table(t,X(:,3),X(:,6),X(:,9),X(:,12),X(:,15));
writetable(T1,filename,'Sheet',1)
writetable(T2,filename,'Sheet',2)
system('taskkill /F /IM EXCEL.EXE')