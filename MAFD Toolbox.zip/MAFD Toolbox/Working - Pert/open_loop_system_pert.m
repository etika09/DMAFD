clear all
close all
m = 5; %number of microgrids
sigma_i = [1 2]; %mode nummbers in each microgrid (this is \sigma_i from the paper)
n_m = 2; %number of switching modes for each microgrid 
sigma = combvec(sigma_i,sigma_i,sigma_i,sigma_i,sigma_i)'; %matrix with all possible values of sigma. Each row is a sigma.

num_out = 2*m; % number of outputs for interconnected grid
num_states = 3*m; % number of states for interconnected grid
[n,no_use] = size(sigma); % number of modes for interconnected grid

Jt = [8 12 12 9 10];
Dt = [2.3556 2.2000 2.3556 2.3556 2.0800];
Jw = 1*[8 12 12 9 10];
Dw = 1*[2.3556 2.2000 2.3556 2.3556 2.0800];
Jv = [12.9 10.200 11.5556 10.8333 11.7273];
Dv = [2.5 2 2.2222 2.0833 2.2727];
%% System Matrices
load('Jacobian_5bus_3to5_pert.mat')

for i=1:m
    for j=1:n_m
        if j==1
            Am{i,j} = [-Dt(i)/Jt(i) 0 0;
                        Dt(i)^2/Jt(i)^2 0 0;
                        0 0 -Dv(i)/Jv(i)];
            B1m{i,j} = [-1/Jt(i) 0;
                        Dt(i)/Jt(i)^2 0;
                        0 -1/Jv(i)];
            B2m{i,j} = -B1m{i,j};
            Cm{i,j} = [1 0 0;
                       0 0 1];
            Dm{i,j} = zeros(2);
%            Dm{i,j} = 0.001*eye(2);
        end
        if j==2
            Am{i,j} = [0 1 0;
                       0 -Dw(i)/Jw(i) 0;
                        0 0 -Dv(i)/Jv(i)];
            B1m{i,j} = [0 0;
                        -1/Jw(i) 0;
                        0 -1/Jv(i)];
            B2m{i,j} = -B1m{i,j};
            Cm{i,j} = [0 1 0;
                       0 0 1];
            Dm{i,j} = zeros(2);
           % Dm{i,j} = 0.001*eye(2);
        end
    end
end
% Interconnected microgrid
L = zeros(3*m,3*m);
for i=1:m
    L(3*i-1,:)= H(2*i-1,:);
end
for i = 1:n
    A{i} = zeros(3*m,3*m);
    B1{i} = zeros(3*m,2*m);
    B2{i} = zeros(3*m,2*m);
    C{i} = zeros(2*m,3*m);
    D{i} = zeros(2*m,2*m);
    
    A_temp = zeros(3*m);
    B1_temp = zeros(3*m,2*m);
    B2_temp = zeros(3*m,2*m);
    C_temp = zeros(2*m,3*m);
    D_temp = zeros(2*m,2*m);
    J_temp = zeros(3*m,3*m);
    
    for j = 1:m
        A_temp((3*j-2):(3*j),(3*j-2):(3*j)) = Am{j,sigma(i,j)}; 
        B1_temp((3*j-2):(3*j),(2*j-1):(2*j)) = B1m{j,sigma(i,j)};
        B2_temp((3*j-2):(3*j),(2*j-1):(2*j)) = B2m{j,sigma(i,j)};
        C_temp((2*j-1):(2*j),(3*j-2):(3*j)) = Cm{j,sigma(i,j)};
        D_temp((2*j-1):(2*j),(2*j-1):(2*j)) = Dm{j,sigma(i,j)};
        if sigma(i,j) == 1
            J_temp(3*j-1,3*j-1) = -1/Jt(j);
        end
    end
    A_temp = A_temp + J_temp*L*A_temp;
    B1_temp = B1_temp + J_temp*L*B1_temp;
    B2_temp = B2_temp + J_temp*L*B2_temp;
    
    A{i} = A_temp; %+B1_temp*H; 
    B1{i} = B1_temp;
    B2{i} = B2_temp;
    C{i} = C_temp;
    D{i} = D_temp;
end
%%
A_pert = A;
B1_pert = B1;
B2_pert = B2;
C_pert = C;
D_pert = D;
save('system_matrix_open_loop_3to5_pert.mat','A_pert','B1_pert','B2_pert','C_pert','D_pert')
