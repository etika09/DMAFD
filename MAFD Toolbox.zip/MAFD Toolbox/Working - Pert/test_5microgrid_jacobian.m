clear;
clc;
% %% Sequence impedance and admittance of distribution lines
% k=1000;
% M=k*k;
% Vb=12.66*k;% 12.66 kV
% Sb=M;% 1 kVA
% Zb=Vb^2/Sb;
% V0 = [1;1.0028;0.9996;1.0031;0.9989];
% theta0 = [0*pi/180;0.2329*pi/180;0.1104*pi/180;0.1582*pi/180;0.0518*pi/180];

% %removed 1-4
% V0=[1;1.00822030481525;1.00211433551737;1.01571214326519;0.999624219646891];
% theta0=[0;0.493252023384293;0.227404134846242;0.807969788721833;0.0706344290227039]*pi/180;

% %removed 1-5
% V0=[1;0.978303576378716;0.968416063422244;0.996000744396091;0.963363884156590]; 
% theta0=[0;0.726699263934434;0.763130427938352;0.312434507505927;0.787880436074045]*pi/180;

% removed 2-3
% V0=[1;1.01325441841853;0.997058119138540;1.00624806035713;0.998161968040288];
% theta0=[0;0.699044316165071;0.0119873541483213;0.291625824653327;0.0378653626101089]*pi/180;

%removed 2-4
% V0=[1;1.00257389060426;0.999560707074512;1.00324899225023;0.998904924264889];
% theta0=[0;0.288138049955561;0.135398059418177;0.126670590716080;0.0580569442264533]*pi/180;

%removed 3-5
V0=[1;1.00706404710539;1.00526534392652;1.00441884817844;0.998551675563331];
theta0=[0;0.561094826028272;0.527505168319061;0.253129942345307;0.0386159910150195]*pi/180;

%% Admittance matrix
z14=0.0054+1i*0.0050;
z23=0.0053+1i*0.0046;
z24=0.0125+1i*0.0125;
z35=0.0031+1i*0.0031;
z15=0.0013+1i*0.0006;

% Admittance matrix
Y14=-1/z14;
Y41=-1/z14;
Y23=-1/z23;
Y32=-1/z23;
Y24=-1/z24;
Y42=-1/z24;
Y35=0;%-1/z35;
Y53=0;%-1/z35;
Y15=-1/z15;
Y51=-1/z15;


Y11=-Y14-Y15;
Y22=-Y24-Y23;
Y33=-Y23-Y35;
Y44=-Y14-Y24;
Y55=-Y15-Y35;

Y_i=[Y11 0 0 Y14  Y15;
    0 Y22 Y23 Y24 0;
    0  Y23 Y33 0 Y35;
    Y41 Y42 0 Y44 0
    Y51 0 Y53 0 Y55];
G=real(Y_i);
B=imag(Y_i);
P=zeros(5,1);
Q=zeros(5,1);

for i=1:1:5
    for k=1:1:5
    P(i)=P(i)+V0(i)*V0(k)*(G(i,k)*cos(theta0(i)-theta0(k))+B(i,k)*sin(theta0(i)-theta0(k)));
    Q(i)=Q(i)+V0(i)*V0(k)*(G(i,k)*sin(theta0(i)-theta0(k))-B(i,k)*cos(theta0(i)-theta0(k)));
    end
end

%% Computing Jacobian
m= 5; % number of microgrids
for i=1:m
    for j=1:m
        H11=0;
        H12=0;
        H13 =0;
        H21=0;
        H22=0;
        H23 =0;
        if j==i
            H11 =-Q(j)-B(j,j)*V0(j)^2;
            H13 =P(j)/V0(j)+G(j,j)*V0(j);
            H12 = 0;
            H21=P(j)-G(j,j)*V0(j)^2;
            H23=Q(j)/V0(j)-B(j,j)*V0(j);
            H22 = 0;
        else
            H11=V0(i)*V0(j)*(G(i,j)*sin(theta0(i)-theta0(j))-B(i,j)*cos(theta0(i)-theta0(j)));
            H13=V0(i)*(G(i,j)*cos(theta0(i)-theta0(j))+B(i,j)*sin(theta0(i)-theta0(j)));
            H12 = 0;
            H21=-V0(i)*V0(j)*(G(i,j)*cos(theta0(i)-theta0(j))+B(i,j)*sin(theta0(i)-theta0(j)));           
            H23=V0(i)*(G(i,j)*sin(theta0(i)-theta0(j))-B(i,j)*cos(theta0(i)-theta0(j)));
            H22 = 0;
        end
        H((2*i-1):(2*i),(3*j-2):(3*j))=[H11 H12 H13;
                                        H21 H22 H23];
    end
end
% J = H;
% J(:,3*[1:5]-1)=[];
% [U,S,V]=svd(J);
% save('Sc4.mat','S')

% Jn=[J(:,1) J(:,4) J(:,2) J(:,5) J(:,3) J(:,6)];
% Jn=[Jn(1,:);Jn(4,:);Jn(2,:);Jn(5,:);Jn(3,:);Jn(6,:)];
% N=-(Jn'+Jn)/2;
% e=max(eig(N));
% save('Jacobian_5bus.mat','H')

%% Compute delH
save('Jacobian_5bus_3to5_pert.mat','H')
% Hc = H;
% load('Jacobian_5bus.mat')
% delH = H-Hc;
% save('Change_in_Jacobian_5bus_1to5_out.mat','delH')